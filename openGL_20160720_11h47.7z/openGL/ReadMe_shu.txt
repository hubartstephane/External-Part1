the following headers comes from http://www.opengl.org/registry/

    glcorearb.h
    glext.h
    glxext.h
    wglext.h