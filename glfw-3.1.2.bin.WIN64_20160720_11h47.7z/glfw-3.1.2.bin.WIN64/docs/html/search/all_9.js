var searchData=
[
  ['notitle',['notitle',['../index.html',1,'']]],
  ['native_20access',['Native access',['../group__native.html',1,'']]],
  ['new_20features',['New features',['../news.html',1,'']]],
  ['news_2edox',['news.dox',['../news_8dox.html',1,'']]]
];
